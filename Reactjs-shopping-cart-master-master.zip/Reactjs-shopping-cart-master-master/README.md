# react.js shopping cart

example of shopping cart implemented in react.js and redux.js



## getting started

install dependencies and start local dev server

```sh
npm install
npm start
```
Made changes to learn pull request
