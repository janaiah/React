import React from "react";

export default function Header() {
  return (
    <h2 style={{ textAlign: "center", background: "blueviolet", color: "white",margin:0,padding:0 }}>
      This is a Header
    </h2>
  );
}
