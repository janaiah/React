export const ActionTypes = {
  SET_PRODUCTS: "SET_PRODUCTS",
};
