/* eslint-disable react/prop-types */
import React from "react";

export default function Button(props) {
  return <button>That is my btn {props.text}</button>;
}
